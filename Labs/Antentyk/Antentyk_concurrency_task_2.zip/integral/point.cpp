#include "integral.h"

using namespace integral;

Point :: Point(double x, double y){
    this->x = x;
    this->y = y;
}