import matplotlib.pyplot as plt
plt.plot([1, 2, 3, 4], [963968821 ,484853838,354778977,282038942], 'ro')
plt.axis([0, 5, 0, 1000000000])
plt.ylabel("Час, мкс")
plt.xlabel("Кількість потоків")
plt.show()