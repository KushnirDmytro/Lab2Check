#include <iostream>
#include <math.h>
#include <chrono>
#include <atomic>
#include <thread>
#include <cstring>
#include <fstream>

using namespace std;
/* NOT MY CODE */

inline std::chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D& d)
{
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}

/*(-________-)*/


double subfunct(double x, int m){
    double sum = 0;
    for(int i = 1; i <= m; ++i){
        double res = i * cos( (i + 1) * x + 1);
        sum = sum + res;
    }
    return sum;
}

double shubert(double x1, double x2, int constm){
    return -1 * subfunct(x1, constm) * subfunct(x2, constm);
}

int looop(double* results, double start, double end, int constm, double xstep, double ystep, double sy, double ey){
    double secondsum = 0;
    for (double x = start; x < end; x = x + xstep) {
        for (double y = sy; y <= ey; y = y + ystep) {
            secondsum = secondsum + (xstep * ystep * shubert(x, y, constm));

        }
    }
    *results = secondsum;
}

int main(int argc, char* argv[]) {
	if (argc < 8){
		std::cout << "Too few arguments!" << std::endl;
		return 1;
	}
	
	double absmistake = std::stod(argv[1]); //Absolute mistake
	double relmistake = std::stod(argv[2]); //Relative mistake
	int numofthr = (int)std::stod(argv[3]); // Number of threads
	double sx = std::stod(argv[4]); //Start interval of X
	double ex = std::stod(argv[5]); //End interval of X
	double sy = std::stod(argv[6]); //Start interval of Y
	double ey = std::stod(argv[7]); //End interval of Y
	int m = 5; // constans value m == 5

	int itertostop = 0;
	
	int step = 125;
	double xstep = 0;
	double ystep = 0;
	double lx = fabs(sx - ex);
	double ly = fabs(sy - ey);
	
    auto start_time = get_current_time_fenced();
    double firstsum = 0;
    double secondsum = 1;

    while ((fabs(secondsum - firstsum) >= absmistake or fabs(1 - secondsum/firstsum) >= relmistake) and itertostop <= 7) {
        step = step * 2;
        xstep = lx / step;
        ystep = ly / step;
        firstsum = secondsum;
        secondsum = 0;

        double results[numofthr];
        std::thread threads[numofthr];
        
        for (int thr = 0; thr < numofthr; thr++){
            threads[thr] = std::move(std::thread(looop, results + thr, sx + (lx * thr / numofthr), sx + (lx * (thr + 1) / numofthr), m, xstep, ystep, sy, ey));
        }
        for (int nthr = 0; nthr < numofthr; nthr++){
            threads[nthr].join();
        }
        
        for (int jj = 0; jj < numofthr; jj++){
            secondsum = secondsum + results[jj];
            
        }
		itertostop++;
		std::cout << secondsum << std::endl;

    }
	auto end_time = get_current_time_fenced();
    auto total_time = end_time - start_time;
    std::cout << "Value is " << secondsum << std::endl;
	std::cout << "Absolute mistake is " << fabs(secondsum - firstsum) << std::endl;
	std::cout << "Relative mistake is " << fabs((secondsum - firstsum)/firstsum) << std::endl;
	std::cout << "Time is: " << to_us(total_time) << std::endl;
	
	std::ofstream resultfile;
    resultfile.open("results.csv");
    resultfile << secondsum << "," << to_us(total_time);
    resultfile.close();
    return 0;

}
