import subprocess
import os
import sys


if(len(sys.argv) != 2):
    print("python3 script.py (number of runs)")
    exit()

a = subprocess.run(["make"])

absolute_error = 0.1
relative_error = 0.01

results = []
times = []
nor = int(sys.argv[1])
for i in range(nor):
	b = subprocess.run(["./m", str(absolute_error), str(relative_error), "4", "-100", "100", "-100", "100"])

	while not os.path.isfile("./results.csv"):
		pass
	with open("results.csv") as file:
		lst = list(map(float, file.readline().split(",")))
	results.append(lst[0])
	times.append(lst[1])

res = len(results)
print(results)
for i in range(0, res):
    for j in range(i, res):
        if i != j:
            if abs(results[i] - results[j]) > absolute_error:
                print("Results do not match")
            else:
                print("Results do match")

print("The smallest time: " + str(min(times)))