import subprocess
import os
import sys

a = subprocess.run(["make"])

times = []
for k in range(1, 5):
    for i in range(2):
        
        b = subprocess.run(["./paralel", "-100", "100", "-100", "100", str(k), "840", "0.001"])
        
        with open("program_result.csv") as file:
            time = file.readline().strip().split(",")[-1]
            times.append(time)
    with open("table.csv", 'a') as f:
        f.write(str(k)+"thread, "+",".join(list(map(str, times)))+"\n")
