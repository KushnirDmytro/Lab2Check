import subprocess
import csv

"""
rel_prec - relative precision
abs_prec - absolute precision
thread_num - number of threads
integ_int - integration interval
iter_num - iteration number
"""

CONF_FILE = 'config'
PROG_NAME = './main'
RUN_TIMES = 10

config = {}

def read_config():
    with open(CONF_FILE, 'r') as config_file:
        for line in config_file.readlines():
            key, value = line.strip().split('=')
            if key == 'm' or key == 'threads_num':
                config[key] = int(value)
            else:
                config[key] = float(value)
    return config

def inc_thread_num(**kwargs):
    new_threads_num = kwargs["new_threads_num"]
    old_threads_num = kwargs["old_threads_num"]
    with open(CONF_FILE, 'r') as config_file:
        old_conf = config_file.read()
    with open(CONF_FILE, 'w') as config_file:
        new_conf = old_conf.replace('threads_num=' + str(old_threads_num), 'threads_num=' + str(new_threads_num))
        config_file.write(new_conf)
        config["threads_num"] = new_threads_num


def main():
    config = read_config()
    args = (PROG_NAME)
    with open('eggs.csv', 'w', newline='') as csvfile:
        spamwriter = csv.writer(csvfile)
        for i in range(RUN_TIMES):
            proc = subprocess.Popen(args, stdout=subprocess.PIPE)
            proc_stdout = list(proc.stdout.readlines())
            res, time = float(proc_stdout[0].decode().strip()), float(proc_stdout[1].decode().split(": ")[1].strip())
            spamwriter.writerow([i + 1, res, time])
            inc_thread_num(new_threads_num=config["threads_num"] + 1, old_threads_num=config["threads_num"])
    inc_thread_num(new_threads_num=1, old_threads_num=config["threads_num"])

if __name__ == "__main__":
    main()
