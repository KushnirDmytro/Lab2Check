import sys
import os

def progs_checker():
	autoargs = False
	
	if ('-h' in sys.argv or '--help' in sys.argv):
		print("Made by Roman Stepaniuk\nThis program runs 5 pr_time t3.cpp program and returns all results of t3.cpp and the smallest running time\nIt needs 7 arguments!!!\n",
		"First argument: desirable absolute measurement error lesser than 0.01(e.g. 0.05)\nSecond arg: desirable measurement error(%) - number lesser than 0.001(e.g. 0.001)\n",
		"Third arg: number of threads(e.g. 6)\n Fourth and fifth args: bounds of X(e.g. -100 100)\nSixth and sevenths args: bounds of y(e.g. -100 100)\n",
		"Also you can use argument -auto to start program with default arguments")
		return 1
	elif('-auto' in sys.argv):
		autoargs = True
		
	
	if(len(sys.argv) < 8 and autoargs is False):
		print("Not enough arguments! Use argument '-h' or '--help' for get more info")
		return 0
	
	elif(autoargs is True):
		exa = 0.005
		exv = 0.001
		nthreads = 6
		x1 = -100
		x2 = 100
		y1 = -100
		y2 = 100
	
	else:
		exa = float(sys.argv[1])
		if (float(sys.argv[2]) > 0.001):
			print("Desirable measurement error should be lesser than 0.001!")
			return 0
		exv = float(sys.argv[2])
		if (int(sys.argv[3]) < 1):
			print("Enter correct number of threads(bigger than 0)")
			return 0
		nthreads = int(sys.argv[3])
		x1 = float(sys.argv[4])
		x2 = float(sys.argv[5])
		y1 = float(sys.argv[6])
		y2 = float(sys.argv[7])
	results = []
	pr_time = []
	for i in range(5):
		os.popen("g++ -Og -pthread t3.cpp -o t3")
		str_cmd = "t3 {a1} {a2} {a3} {a4} {a5} {a6} {a7}".format(a1=exa, a2=exv, a3=nthreads, a4=x1, a5=x2, a6=y1, a7=y2)
		p = os.popen(str_cmd)
		for j in p.readlines():
			if str(j).startswith("Result"):
				results.append(float(str(j).split()[-1]))
			elif str(j).startswith("Total"):
				pr_time.append(int(str(j).split()[-2]))
		#print(str(p.readlines()))
		#print(str(p.readlines()[0]).split(), str(p.readlines()[-1]).split())
		#results.append(float(str(p.readlines()[0]).split()[-1]))
		#pr_time.append(int(str(p.readlines()[-1]).split()[-2]))
		
	#print(results, pr_time)
	for i in range(len(results)):
		for j in range(i + 1, len(results)):
			if results[i] - results[i] > exa:
				print('Results have too big absolute measuring error... \nResults: ' + results + '\npr_time: ' + pr_time)
				return 1
	print('All 5 results are correct, minimal time: ' + str(min(pr_time)))
	print('Results:', results, pr_time)
	return True, min(pr_time)
	
progs_checker()
