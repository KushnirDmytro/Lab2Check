#include <iostream>
#include<thread>
#include <chrono>
#include <atomic>
#include <mutex>
#include <vector>
#include <cmath>
#include <string.h>


double func3(double x, double y){
	double f1 = 0; 
	double f2 = 0;
	int m = 5;
	for(int i = 1; i < m + 1; i++){
		f1 += i*(cos((i + 1) * x + 1));
		f2 += i*(cos((i + 1) * y + 1));
	}
	return -1 * f1 * f2;
}


double integral(int x1, int x2, int y1, int y2, double step, std :: mutex& m, double &res){
	double thr_sum = 0;
	for(double s1 = x1; s1 < x2; s1 += step){
		for(double s2 = y1; s2 < y2; s2 += step){
			double p1 = s1 + step;
			double p2 = s2 + step;
			thr_sum += func3((p1 + s1) / 2, (p2 + s2) / 2) * pow(step, 2);
		}
	}
	m.lock();
	res += thr_sum;
	m.unlock();
}

inline std::chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D& d)
{
    return std::chrono::duration_cast<std::chrono::seconds>(d).count();
}


int main(int argc, char* argv[]) {
	double expl = -5.045849736;
	double exa, x1, x2, y1, y2, exv;
	bool autoargs = false;
	int nthreads; 
	for(int i = 1; i < argc; ++i){
		if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0){
			std::cout << "Made by Roman Stepaniuk\nThis program evaluates integral of equality.\nIt needs 7 arguments!!!\n"
			"First argument: desirable absolute measurement error lesser than 0.01(e.g. 0.05)\nSecond arg: desirable measurement error(%) - number lesser than 0.001(e.g. 0.001)\n"
			"Third arg: number of threads(e.g. 6)\n Fourth and fifth args: bounds of X(e.g. -100 100)\nSixth and sevenths args: bounds of y(e.g. -100 100)\n"
			"Also you can use argument -auto to start program with default arguments" << std::endl;
			exit(EXIT_SUCCESS);
		}
		else if(strcmp(argv[i], "-auto") == 0){
			autoargs = true;
		}
	}
	if(argc < 8 && !autoargs){
		std::cout << "Not enough arguments! Use argument '-h' or '--help' for get more info" << std::endl;
		exit(EXIT_FAILURE);
	}
	else if(autoargs){
		exa = 0.005;
		exv = 0.001;
		nthreads = 6;
		x1 = -100;
		x2 = 100;
		y1 = -100;
		y2 = 100;
	}
	else{
		exa = atof(argv[1]);
		if (atof(argv[2]) > 0.001){
			std::cout << "Desirable measurement error should be lesser than 0.001!" << std::endl;
 			exit(EXIT_FAILURE);
		}
		exv = atof(argv[2]);
		if (atof(argv[3]) < 1){
			std::cout << "Enter correct number of threads(bigger than 0)" << std::endl;
			exit(EXIT_FAILURE);
		}
		nthreads = atoi(argv[3]);
		x1 = atof(argv[4]);
		x2 = atof(argv[5]);
		y1 = atof(argv[6]);
		y2 = atof(argv[7]);
	}
	std::mutex m;
	double steps = 200;
	double ea1, ea2, ev1, ev2, r1, r2;
    double res;
	auto stage1_start_time = get_current_time_fenced();
	while ((fabs(r2 - r1) > exa) || (fabs((r2 - r1) / r2) > exv) || (steps == 200)){
		std::vector<std::thread> threads;
		double dif = (x2 - x1) / steps;
		int start = x1;
		int end = start + ((x2 - x1) / nthreads);
		res = 0;
		for(int i = 0; i < nthreads; ++i){
			if(i == nthreads - 1){
				end = x2;
			}
			threads.emplace_back(integral, start, end, y1, y2, dif, std::ref(m), std::ref(res));
			start += ((x2 - x1) / nthreads);
			end += ((x2 - x1) / nthreads);
		}
		for(auto& thread : threads){
			thread.join();
		}
		r1 = r2;
		r2 = res;
		ea2 = fabs(expl - res);
		ev2 = fabs(ea2 / expl);
		steps *= 2;
	}
	std::cout << "Result: " << res << "\nAbsolute measuring error: " << ea2 << "\nMeasuring error: " << fabs(ev2) << std::endl;
		
    auto finish_time = get_current_time_fenced();
    auto total_time = finish_time - stage1_start_time;
    std::cout << "Total time: " << to_us(total_time) << " sec" << std::endl;

}
