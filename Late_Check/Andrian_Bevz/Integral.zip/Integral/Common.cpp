//
// Created by drbutthurt on 20.04.18.
//
#include "Common.h"


double function(double x1, double x2) {
    double res = 0.002;
    for (int i=-2; i<3; i++) {
        for (int j=-2; j<3; j++) {
            double lower = 5*(i + 2) + j + 3 + pow((x1 - 16*j), 6) + pow((x2 - 16*i), 6);
            res += 1.0/lower;
        }
    }
    return 1.0/res;
}


double integral(double x1_start, double x1_end, double x2_start, double x2_end, int divisions) {
    double step_x1 = fabs(x1_end - x1_start) / divisions;
    double step_x2 = fabs(x2_end - x2_start) / divisions;
    double area = step_x1 * step_x2;

    double res = 0;

    for (int i=0; i<divisions; i++) {
        double x1 = x1_start + step_x1 * i;
        for (int j=0; j<divisions; j++) {
            double x2 = x2_start + step_x2 * j;
            res += function(x1, x2) * area;
        }
    }

    return res;
}
