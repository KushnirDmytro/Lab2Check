//
// Created by drbutthurt on 20.04.18.
//

#ifndef INTEGRAL_COMMON_H
#define INTEGRAL_COMMON_H

#include <cmath>
#include <iostream>
#include <cstdlib>

#include <chrono>
#include <atomic>

using namespace std;


double function(double x1, double x2);

double integral(double x1_start, double x1_end, double x2_start, double x2_end, int divisions);

inline std::chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D& d)
{
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}

#endif //INTEGRAL_COMMON_H
