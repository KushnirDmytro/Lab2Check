//
// Created by drbutthurt on 21.04.18.
//

#include "Common.h"

double calculate(double x1_start, double x1_end, double x2_start, double x2_end, double precision);

int main(int argc, char* argv[]) {
    int x1_start = atoi(argv[1]);
    int x1_end = atoi(argv[2]);
    int x2_start = atoi(argv[3]);
    int x2_end = atoi(argv[4]);
    double precision = pow(10.0, -atoi(argv[5]));


    cout << "Starting consecutive" << endl;

    auto start = get_current_time_fenced();

    double res = calculate(x1_start, x1_end, x2_start, x2_end, precision);

    auto finish = get_current_time_fenced();
    auto total = finish - start;

    cout.precision(15);
    cout << "Result: " << res << endl;
    cout << "Consecutive time, ms:\n" << (int)((double)to_us(total)/1000) << endl;

    return 0;
}

double calculate(double x1_start, double x1_end, double x2_start, double x2_end, double precision) {
    double intgrl1 = integral(x1_start, x1_end, x2_start, x2_end, 250);
    double intgrl2 = integral(x1_start, x1_end, x2_start, x2_end, 500);
    double diff = fabs(intgrl2 - intgrl1);
    int divs = 1000;
    while (diff > precision) {
        intgrl1 = intgrl2;
        intgrl2 = integral(x1_start, x1_end, x2_start, x2_end, divs);
        diff = fabs(intgrl2 - intgrl1);
        divs *= 2;
    }
    return intgrl2;
}
