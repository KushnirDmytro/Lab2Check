//
// Created by drbutthurt on 21.04.18.
//

#include "Common.h"
#include <thread>
#include <mutex>
#include <vector>

double calculate(double x1_start, double x1_end, double x2_start, double x2_end, double precision, int threads);
double threadIntegral(double x1_start, double x1_end, double x2_start, double x2_end, int divisions, int threads);


int main(int argc, char* argv[]) {
    int x1_start = atoi(argv[1]);
    int x1_end = atoi(argv[2]);
    int x2_start = atoi(argv[3]);
    int x2_end = atoi(argv[4]);
    double precision = pow(10.0, -atoi(argv[5]));
    int threads = atoi(argv[6]);

    cout << "Precision: " << precision << endl;

    auto start = get_current_time_fenced();

    double res = calculate(x1_start, x1_end, x2_start, x2_end, precision, threads);

    auto finish = get_current_time_fenced();
    auto total = finish - start;
    
    cout.precision(15);
    cout << "Result: " << res << endl;
    cout << "Parallel time, ms:\n" << (int)((double)to_us(total)/1000) << endl;

    return 0;
}


void launchThread(double* res, mutex& m, double x1_start, double x1_end,
                  double x2_start, double x2_end, int divisions) {
    double localRes = integral(x1_start, x1_end, x2_start, x2_end, divisions);
    m.lock();
    *res += localRes;
    m.unlock();
}

double calculate(double x1_start, double x1_end, double x2_start, double x2_end, double precision, int threads) {
    double intgrl1 = threadIntegral(x1_start, x1_end, x2_start, x2_end, 250, threads);
    double intgrl2 = threadIntegral(x1_start, x1_end, x2_start, x2_end, 500, threads);
    double diff = fabs(intgrl2 - intgrl1);
    int divs = 1000;
    while (diff > precision) {
        intgrl1 = intgrl2;
        intgrl2 = threadIntegral(x1_start, x1_end, x2_start, x2_end, divs, threads);
        diff = fabs(intgrl2 - intgrl1);
        divs *= 2;
    }
    return intgrl2;
}

double threadIntegral(double x1_start, double x1_end, double x2_start, double x2_end, int divisions, int threads) {
    double x1_thread_step = fabs(x1_end - x1_start) / threads;
    double x2_thread_step = fabs(x2_end - x2_start) / threads;

    int divisionsStep = divisions / threads;

    vector<thread> threadVector = {};
    double res = 0;
    mutex m;

    for (int i=0; i<threads; i++) {
        double x1_thread_start = x1_start + x1_thread_step * i;
        double x1_thread_end = x1_thread_start + x1_thread_step;

        for (int j=0; j<threads; j++) {
            double x2_thread_start = x2_start + x2_thread_step * j;
            double x2_thread_end = x2_thread_start + x2_thread_step;

            threadVector.emplace_back(thread(launchThread, &res, ref(m), x1_thread_start, x1_thread_end,
                                             x2_thread_start, x2_thread_end, divisionsStep));
        }
        for (int j=0; j<threads; j++) {
            threadVector[j].join();
        }
        threadVector.clear();
    }
    return res;
}
