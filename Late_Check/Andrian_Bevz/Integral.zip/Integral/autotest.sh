#!/usr/bin/env bash

./test.sh 0 10 -50 50 -50 50 3
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -50 50 -50 50 3 1
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -50 50 -50 50 3 2
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -50 50 -50 50 3 3
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -50 50 -50 50 3 4
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -50 50 -50 50 3 6
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -50 50 -50 50 3 8
echo -e "\n\n\n\n\n\n"
sleep 10
./test.sh 0 10 -100 100 -100 100 3
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -100 100 -100 100 3 1
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -100 100 -100 100 3 2
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -100 100 -100 100 3 3
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -100 100 -100 100 3 4
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -100 100 -100 100 3 6
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -100 100 -100 100 3 8
echo -e "\n\n\n\n\n\n"
sleep 10
./test.sh 0 10 -25 25 -25 25 2
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -25 25 -25 25 2 1
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -25 25 -25 25 2 2
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -25 25 -25 25 2 3
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -25 25 -25 25 2 4
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -25 25 -25 25 2 6
echo -e "\n\n\n"
sleep 10
./test.sh 1 10 -25 25 -25 25 2 8
