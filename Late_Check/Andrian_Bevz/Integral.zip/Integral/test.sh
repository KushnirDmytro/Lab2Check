#!/usr/bin/env bash

MODE=$1
RUNS=$2
X1_START=$3
X1_END=$4
X2_START=$5
X2_END=$6
PRECISION=$7
THREADS=$8

MAX_THREADS=$(nproc --all)


cd cmake-build-release

TOTAL=0

if [ $MODE == 0 ]
then
    make consecutive

    for ((i=1;i<=$RUNS;i++))
    do
        echo "Starting run $i"
        OUTPUT=$(./consecutive $X1_START $X1_END $X2_START $X2_END $PRECISION| tail -1)
        echo "Result: $OUTPUT"
        let "TOTAL+=$OUTPUT"
    done

    echo "Consecutive tests completed"
fi

if [ $MODE == 1 ]
then
    if [ $THREADS -gt $MAX_THREADS ]
    then
        echo "Too many threads, max is $MAX_THREADS"
        exit 1
    fi

    make parallel

    for ((i=1;i<=$RUNS;i++))
    do
        echo "Starting run $i"
        OUTPUT=$(./parallel $X1_START $X1_END $X2_START $X2_END $PRECISION $THREADS| tail -1)
        echo "Result: $OUTPUT"
        let "TOTAL+=$OUTPUT"
    done

    echo ""
    echo "Parallel tests completed"
    echo "Threads: $THREADS"
fi

AVERAGE=$((TOTAL/RUNS))

echo "Runs: $RUNS"
echo "Total time: $TOTAL"
echo "Average time: $AVERAGE"

exit 0
