//
// Created by cs.ucu.edu.ua on 4/5/2018.
//
#include <cmath>
#include <iostream>
#include <chrono>
#include <atomic>
using namespace std;
inline std::chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D& d)
{
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}
double func(double x, double y) {
    double a = 20;
    double b = 0.2;
    double c = M_PI * 2;
    double res = -a * exp(-b * sqrt(((pow(x, 2)) + (pow(y, 2))) / 2)) - exp((cos(c * x) + cos(c * y)) / 2) + a + exp(1);
    return res;
}
double integral_func(double st_x, double fn_x, double st_y, double fn_y, int intervs_x, int intervs_y) {
    double x_period = (fn_x - st_x) / intervs_x;
    double y_period = (fn_y - st_y) / intervs_y;
    double result = 0;
    for(int i = 0; i<intervs_x; i++){
        double x = st_x + i * x_period;
        for(int j = 0; j<intervs_y; j++){
            double y = st_y + j * y_period;
            result += func(x,y) * x_period * y_period;
        }
    }
    return result;
}

double calculate_concur(double st_x, double fn_x, double st_y, double fn_y, double precision) {
    double difference = precision * 2;
    int intervs = 250;
    double result2 = 0;
    double result1 = integral_func(st_x, fn_x, st_y, fn_y, intervs, intervs);
    while (difference > precision) {
        intervs *= 2;
        result2 = integral_func(st_x, fn_x, st_y, fn_y, intervs, intervs);
        difference = fabs(result2 - result1);
        if (difference < precision) {
            break;
        }
        result1 = result2;
    }
    return result2;
}

int main(int argc, char *argv[]) {
    auto stage1_start_time = get_current_time_fenced();
    double integral = calculate_concur(-100, 100, -100, 100, 0.001);
    auto finish_time = get_current_time_fenced();
    auto total_time = finish_time - stage1_start_time;
    cout.precision(20);
    cout << to_us(total_time) <<endl;
    return 0;
}