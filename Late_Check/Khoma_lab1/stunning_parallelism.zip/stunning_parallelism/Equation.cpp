#include <thread>
#include <vector>
#include <mutex>
#include <algorithm>


#include "Equation.h"

using namespace std;


void Equation::simpleCountEquation() {

    for (int W : vector1) {
        for (int X : vector1) {
            for (int Z : vector1) {
                for (int Y : vector1) {
                    if(!((W == Y && X == Z) || (W == Z && X == Y))){
                        if(pow(W,3) + pow(X,3) == pow(Z,3) +pow(Y,3)){
                            result++;
                        }
                    }
                }

            }

        }

    }
}


void Equation::parallelCountEquation(int thread_num) {
    int start = 0;
    int end = 0;
    vector<thread> threads;
    mutex mut;


    for (int i = 1; i <= thread_num; i++)
    {
        if(i == thread_num)
        {
            end = vector1.size();
        }
        else
        {
            end += vector1.size()/thread_num;
        }
        threads.emplace_back(thread(&Equation::helpToCount,this, start, end, ref(mut)));
        start = end;
    }
    for (int i = 0; i < thread_num; i++)
    {
        threads[i].join();
    }

}

void Equation::helpToCount(int start, int end, mutex &mut) {
    int local_result =0;

    for (int W = start; W < end ; W++) {
        for (int X = 0; X < vector1.size(); X++) {
            for (int Z = 0; Z < vector1.size(); Z++) {
                for (int Y = 0; Y < vector1.size(); Y++) {
                    if(!((vector1[W] == vector1[Y] && vector1[X] == vector1[Z]) ||
                         (vector1[W] == vector1[Z] && vector1[X] == vector1[Y]))){
                        if(pow(W,3) + pow(X,3) == pow(Z,3) +pow(Y,3)){
                            local_result ++;
                            }
                        }
                    }
                }
            }

        }

        lock_guard<mutex> lock(mut);
        result+= local_result;
    }


