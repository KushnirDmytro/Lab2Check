#ifndef STUNNING_PARALLELISM_EQUATION_H
#define STUNNING_PARALLELISM_EQUATION_H

#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
#include <mutex>

class Equation {
private:
    std::vector<int> vector1;
    int result;

    void  helpToCount(int start, int end, std::mutex & mu);

public:

    Equation(){

        result = 0;
        vector1 = std::vector<int>(50);
        std::iota (std::begin(vector1), std::end(vector1), 1);
    }

    void simpleCountEquation();

    void parallelCountEquation(int thread_num);


    int getResult() const {
        return result;
    }

    void setResult(int result) {
        Equation::result = result;
    }

    virtual ~Equation() {
        std::cout << "-----------------------------------------------------------------------------------" << std::endl;
        std::cout << ";=)" << std::endl;
    }
};


#endif //STUNNING_PARALLELISM_EQUATION_H
