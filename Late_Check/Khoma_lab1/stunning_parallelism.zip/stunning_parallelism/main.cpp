#include <iostream>
#include <chrono>
#include <atomic>
#include <fstream>
#include <sstream>
#include <map>
#include <boost/program_options.hpp>
#include <algorithm>

#include "Equation.h"

namespace po = boost::program_options;
using namespace std;


//----------------TIME_CODE_START--------------------------------------------------
inline std::chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D& d)
{
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}
//----------------TIME_CODE_END--------------------------------------------------

//----------------MAIN_FUNC_CODE_START--------------------------------------------------
int main(int argc, char** argv) {
//---------------------------init_start---------------------------------------------------
    int thread_num = 1;
    Equation equation;
    string filename("../configurations.txt");

    std::ifstream config_stream(filename);
    string line;
    config_stream >> line;
    int num = stoi(line);
    config_stream.close();

    if(num <=0 || num >= 9){
        std::cout << "Bad param!" << std::endl;
        exit(-1);
    }

    thread_num = num;
//---------------------------init_end---------------------------------------------------

//---------------------------main_body_start--------------------------------------------

    auto start_time1 = get_current_time_fenced();

    equation.simpleCountEquation();
    int result1 = equation.getResult();
    equation.setResult(0);

    auto start_time2 = get_current_time_fenced();

    equation.parallelCountEquation(thread_num);
    int result2 = equation.getResult();
    equation.setResult(0);

    auto finish_time = get_current_time_fenced();

    auto total_time = finish_time - start_time1;
    auto stage_time1 = start_time2 - start_time1;
    auto stage_time2 = finish_time - start_time2;

//---------------------------main_body_end--------------------------------------------

//---------------------------outputs_start--------------------------------------------

    cout << "Simple results: " << result1 << endl;
    cout << "Parallel results: " << result2 << endl;

    cout << "Total time: " << to_us(total_time) << endl;
    cout << "Stage 1 time: " << to_us(stage_time1) << endl;
    cout << "Stage 2 time: " << to_us(stage_time2) << endl;

//---------------------------outputs_end--------------------------------------------
    return 0;
}
//----------------MAIN_FUNC_CODE_END--------------------------------------------------
