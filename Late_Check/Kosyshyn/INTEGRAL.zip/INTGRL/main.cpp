#include <iostream>
#include <chrono>
#include <atomic>
#include <cmath>
#include <mutex>
#include <string>
#include <cstring>
#include <thread>
#include <vector>
#include <fstream>

using namespace std;

inline std::chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class T>
inline long long to_us(const T& t)
{
    return std::chrono::duration_cast<std::chrono::microseconds>(t).count();
}

double intgrl(double x, double y){
    double r = 0;
    for(int i = -2; i<=2; i++){
        for(int j=-2; j<=2; j++){

            r+=1/(5*(i+2)+j+3+pow((x - 16*j), 6)+pow((y-16*i),6));
        }
    }
    double rez = pow((0.002+r),-1);
    return rez ;
}


void area_calc(double step, double start, double end, double min_y, double max_y, double *result, std::mutex &m){
    double lockal_r = 0;
    for(double x=start; x<end; x += step)
        for(double y=min_y; y<=max_y; y += step)
            lockal_r += intgrl((x+x+step)/2, (y+y+step)/2);

    m.lock();
    *result += lockal_r;
    m.unlock();
}
double counting_in_threads(double min_x, double max_x, double min_y, double max_y, double  step, int threads){
    mutex m;

    double res = 0;
    int calc = (int)max_x-(int)min_x;
    int numb_calc_per_p = calc/threads;
    int numb_calc_for = calc%threads;
    vector<thread> t_array;
    double start = min_x;

    for(int i=0; i<threads; ++i){
        double end = start+numb_calc_per_p;
        if(i==threads-1){
            double end = start+numb_calc_per_p+numb_calc_for;
        }

        t_array.emplace_back(area_calc, step, start,end ,min_y, max_y, &res, std::ref(m));
        start+=numb_calc_per_p;
    }

    for(auto &threads : t_array){
        threads.join();
    }
    return res;
}
int main(int argc, char* argv[]) {
    if(argc != 8){
        std::cerr << "Invalid number of arg, should be 8" << std::endl;
        return 1;
    }


    double absolute_error = stod(argv[1]);
    if(absolute_error <= 0){
        std::cerr << "absolute_error should be positive" << std::endl;
        return 1;
    }

    double rel_error = stod(argv[2]);

    if(rel_error < 0.001){
        std::cerr << "relativistic_error can't be less than 0.001" << std::endl;
        return 1;
    }
    int threads = atoi(argv[3]);
    if(threads < 1){
        std::cerr << "number of threads should be greater than 0 " << std::endl;
        return 1;
    }


    double min_x =stod(argv[4]);
    double max_x = stod(argv[5]);
    if(max_x < min_x){
        std::cerr << "maximal number should be greater than minimal" << std::endl;
        return 1;
    }
    double min_y =std::stod(argv[6]);
    double max_y = std::stod(argv[7]);
    if(max_y < min_y){
        std::cerr << "maximal number should be greater than minimal" << std::endl;
        return 1;
    }
    auto start_time = get_current_time_fenced();


    int calc = (int)max_x-(int)min_x;
    double result = 0;
    double previous_result = 0;
    double step = 2;

    bool continue_comparing = true;

    while (continue_comparing){


        result = counting_in_threads(min_x, max_x, min_y, max_y, step, threads);
        if(previous_result != 0) {
            bool abs_err = fabs(previous_result - result);
            bool rel_err = fabs((result - previous_result) / result);
            continue_comparing = (abs_err > absolute_error) && (rel_err > rel_error);
        }
        previous_result = result;


    }

    result *= step*step;

    auto finish_time = get_current_time_fenced();
    auto total_time = finish_time - start_time;

    std::cout << "Number of threads: " << threads << std::endl;
    std::cout << "Total time: " << to_us(total_time) << std::endl;
    std::cout << "Result: " << result << std::endl;

    std::ofstream rez;
    rez.open("result.csv");
    rez << threads << "," << result << "," << to_us(total_time);
    rez.close();
    return 0;
}
