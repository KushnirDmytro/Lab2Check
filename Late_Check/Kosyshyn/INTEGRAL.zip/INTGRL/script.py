import subprocess
import sys


n=10
with open("config") as config:
    line = config.readline().split(",")
abs_error = line[0]
rel_error = line[1]
threads = line[2]
min_x = line[3]
max_x =line[4]
min_y =line[5]
max_y =line[6]

time = []
result=0
current_result=0

#cmake = subprocess.run(["/usr/bin/cmake ./CMakeLists.txt"])

make = subprocess.run(["make"])

for i in range(n):
    subprocess.call(["./INTGRL", abs_error,  rel_error, threads, min_x, max_x, min_y, max_y])
    with open("result.csv") as rez:
        line = rez.readline().split(",")
    current_result=(line[1])
    time.append(int(line[2]))
    if i > 1 and result!=current_result:
        print ("program works incorrect ")
        break
    result = current_result

print((time))
print(min(time))