import subprocess
import sys


if(len(sys.argv)!=2):
    exit()
n=int(sys.argv[1])
with open("config") as config:
    line = config.readline().split(",")
abs_error = line[0]
rel_error = line[1]
threads = line[2]
min_x = line[3]
max_x =line[4]
min_y =line[5]
max_y =line[6]
results = []
time = []

#cmake = subprocess.run(["/usr/bin/cmake ./CMakeLists.txt"])

make = subprocess.run(["make"])

for i in range(n):
    subprocess.call(["./INTGRL", abs_error,  rel_error, threads, min_x, max_x, min_y, max_y])
    with open("result.csv") as rez:
        line = rez.readline().split(",")
    results.append(line[1])
    time.append(line[2])
cnt=0
for i in range(0, len(results)-2):

    if abs(float(results[i]) - float(results[i+1])) > float(abs_error):
        print("ploho")
        break
    cnt+=1

if cnt == len(results)-2:
    print("Vse ok")

print(min(time))