#include <iostream>
#include <chrono>
#include <atomic>
#include <fstream>
#include <math.h>
#include <thread>
#include <mutex>
#include <ctype.h>
#include <cctype>
#include <string>
#include <vector>
#include <algorithm>
#include <stdio.h>
#include <chrono>
#include <atomic>
#include <thread>
using std::mutex;
using namespace std;

inline std::chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D& d)
{
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}

double func(double x1, double x2){
    double a = 20;
    double b = 0.2;
    double c = 2 * M_PI;
    return -a * exp(-b * sqrt(1.0/2 * (x1*x1 + x2*x2))) - exp(1.0/2 * (cos(c * x1) + cos(c * x2))) + a + exp(1);
}

void integrate(double minx, double maxx, double miny, double maxy, size_t stepsx, size_t stepsy, double &res,
          mutex &m) {
    
    double dif_x = (maxx - minx) / stepsx;
    double dif_y = (maxy - miny) / stepsy;
    double x1 = minx;
    double x2 = maxx;
    double y1 = miny;
    double y2 = maxy;

    while (fabs(x2 - x1) > 0.0001) {
        while (y1 <= y2) {
            double x_1 = (x1 + (x1 + dif_x)) / 2;
            double y_1 = (y1 + (y1 + dif_y)) / 2;
            res += func(x_1, y_1) * dif_x * dif_y;
            y1 += dif_y;
        }
        x1 += dif_x;
        y1 = miny;
    }
}

vector <string> get_config(string filename){
    ifstream file(filename);
    vector<string> config;
    string word;
    if (file.is_open()) {
        while (file >> word) {
            config.push_back(word.substr(word.find("=") + 1));
        }
    } else {
        cerr << "Couldn't open the configuration file." << endl;
    }
    return config;
}

int main() {
    
    vector<string> conf = get_config("configurations.txt");
    cout << conf.at(0).substr(1, conf.at(0).size() - 2) << endl;
    
    size_t steps = 250;
    double cAbsError, cRelError;
    mutex mx;
    
    int thr = atoi(conf.at(0).c_str());
    double x1 = stod(conf.at(1).c_str());
    double x2 = stod(conf.at(2).c_str());
    double y1 = stod(conf.at(3).c_str());
    double y2 = stod(conf.at(4).c_str());
    double absoluteError = stod(conf.at(5).c_str());
    double relativeError = stod(conf.at(6).c_str());
    double concreteAbsError;
    double concreteRelError;

    auto start_time = get_current_time_fenced();
    
    vector<std::thread> threads;
    vector<double> res(thr, 0);

    double start = x1; 
    double step = (x2 - x1) / thr;
    double finish = start + step;
    
    size_t steps_integr_x = (size_t) (steps / thr);
    size_t steps_integr_y = steps;

    for (int i = 0; i < thr; ++i) {
        if (i == (thr - 1)) {
            finish = x2;
        }

        threads.push_back(thread(integrate, start, finish, y1, y2, steps_integr_x,steps_integr_y, ref(res[i]), ref(mx)));

        start = finish;
        finish += step;
    }

    for (auto &thread: threads)
        thread.join();

    double result1 = accumulate(begin(res), end(res), (double) 0.0);
    double result2;
    
    while (true) {
        steps *= 2;

        vector<std::thread> threads;
        vector<double> res(thr, 0);
        
        start = x1; 
        step = (x2 - x1) / thr;
        finish = start + step;
    
        steps_integr_x = (size_t) (steps / thr);
        steps_integr_y = steps;

        for (int i = 0; i < thr; ++i) {
            if (i == (thr - 1)) {
                finish = x2;
            }

            threads.push_back(thread(integrate, start, finish, y1, y2, steps_integr_x,steps_integr_y, ref(res[i]), ref(mx)));

            start = finish;
            finish += step;
        }

        for (auto &thread: threads)
            thread.join();

        result2 = accumulate(begin(res), end(res), (double) 0.0);

        concreteAbsError = fabs(result2 - result1);
        concreteRelError = fabs(1 - (result1 / result2));

        if ((concreteAbsError < absoluteError) && (concreteRelError < relativeError)) {
            break;
        } else {
            result1 = result2;
        }
    }
    
    auto finish_time = get_current_time_fenced();
    
    std::cout << to_us(finish_time - start_time) << std::endl;
    std::cout << concreteAbsError << std::endl;
    std::cout << concreteRelError << std::endl;
    std::cout << result2 << std::endl;
    return 0;
}
