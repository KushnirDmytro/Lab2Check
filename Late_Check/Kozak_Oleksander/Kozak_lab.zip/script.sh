#!/bin/bash

# Initialization
PATH_WITH_PROGRAM='./main'
ITERATIONS=10

MIN_TIME=99999999999999

for i in "$@"
do
case $i in
    -p=*|--path=*)
    PATH_WITH_PROGRAM="${i#*=}"
    shift
    ;;
    -i=*|--iterations=*)
    ITERATIONS="${i#*=}"
    shift
    ;;
    *)
          # unknown option
    ;;
esac
done

results=()

for (( i=1; i<= ${ITERATIONS}; i++ ))
do

   RESULT=$(${PATH_WITH_PROGRAM})

   RES_ARR=( $RESULT )
   results[i]=${RES_ARR[0]}

   echo "Res"${i}": "${RES_ARR[0]} # Result

    if ((${MIN_TIME} > ${RES_ARR[1]})); then
       MIN_TIME=${RES_ARR[1]}
    fi
done

echo "Minimum computation time: "${MIN_TIME} 
