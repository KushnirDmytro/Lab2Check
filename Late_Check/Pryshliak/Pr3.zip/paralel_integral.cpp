#include <iostream>
#include <fstream>
#include <limits>
#include <chrono>
#include <cassert>
#include <atomic>
#include <cmath>
#include <exception>
#include <stdexcept>
#include <string>
#include <list>
#include <iomanip>
#include <thread>
#include <vector>
#include <mutex>

using namespace std;


inline std::chrono::steady_clock::time_point get_current_time_fenced(){
    assert(std::chrono::steady_clock::is_steady &&
                   "Timer should be steady (monotonic).");
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::steady_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}


template<class D>
inline long long to_us(const D& d){
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}


struct configuration_t
{
    double rel_err, abs_err;
    double minx, miny, maxx, maxy;
    int m;
    int steps, max_steps;
    int numb_of_thr;
};


configuration_t read_conf(istream& cf){
    ios::fmtflags flags( cf.flags() );
    cf.exceptions(std::ifstream::failbit);

    configuration_t res;
    string temp;

    try {
        cf >> res.rel_err;
        getline(cf, temp);
        cf >> res.abs_err;
        getline(cf, temp);
        cf >> res.minx;
        getline(cf, temp);
        cf >> res.miny;
        getline(cf, temp);
        cf >> res.maxx;
        getline(cf, temp);
        cf >> res.maxy;
        getline(cf, temp);
        cf >> res.m;
        getline(cf, temp);
        cf >> res.steps;
        getline(cf, temp);
        cf >> res.max_steps;
        getline(cf, temp);
        cf >> res.numb_of_thr;
        getline(cf, temp);
    }catch(std::ios_base::failure &fail)
    {
        cf.flags( flags );
        throw;
    }
    cf.flags( flags );
    if( res.minx >= res.maxx ) {
        throw std::runtime_error("min x should be < max x");
    }
    if( res.miny >= res.maxy ) {
        throw std::runtime_error("min y should be < max y");
    }
    if( res.steps < 10 ) {
        throw std::runtime_error("Too few initial_steps");
    }
    if( res.max_steps < 10 ) {
        throw std::runtime_error("Too small max_steps");
    }
    if( res.abs_err <=0 || res.rel_err <= 0 )
    {
        throw std::runtime_error("Errors should be positive");
    }
    if( res.numb_of_thr <=0 )
    {
        throw std::runtime_error("Number of threads should be positive");
    }

    return res;
}


double shuberts_func(double x, double y, int m){
    double res = 0;
    double res1 = 0;
    double res2 = 0;
    for(int i=1; i<m+1; i++){
        res1 += i * cos((i+1)*x + 1);
        res2 += i * cos((i+1)*y + 1);
    }
    res = -res1 * res2;
    return res;
}


void shuberts_integral(double minx, double miny,double maxx, double maxy, int m, int steps, int max_steps, double &res){
    double l_res = 0;
	mutex mx;
    double delta_x = (maxx - minx)/max_steps;
    double delta_y = (maxy - miny)/max_steps;
    for(int i=steps; i<max_steps; i++){
        double x = minx + i*delta_x;
        for(int j=steps; j<max_steps; j++){
            double y = miny + j*delta_y;
            l_res +=shuberts_func(x, y, m)*delta_x*delta_y;
        }
    }
	mx.lock();
	res += l_res;
	mx.unlock();
}




double thread_shuberts_integral(double minx, double miny,double maxx, double maxy, int m, int steps,int max_steps, double abs_err,
                            double rel_err,double &cur_abs_err, double &cur_rel_err, int n_threads){
	double cur_res, prev_res;
	std::vector<double> pr_res; 
	while(1){
		std::vector<int> stps;
		std::vector<double> res;
		int counter = 0;
		for (int i = 0; i < n_threads; i++){
			stps.push_back(steps);
			counter += 1;
			res.push_back(0);
			steps *= 2;
			if (steps > max_steps){
				break;
			}
		}	
		cur_res = 0;
		prev_res = 0;
		std::thread thread_v[counter];
		for (int i = 0; i < counter; i++){
			thread_v[i] = std::thread(shuberts_integral, minx, miny, maxx, maxy, m,
									 0, stps[i], std::ref(res[i]));
		}

		for (int i = 0; i < counter; i++){
			if (thread_v[i].joinable()){
				thread_v[i].join();
			}
		}
		
		for(int i=0; i<counter; i++){
			if (i == 0){
				if (pr_res.size() == 0){
					cur_res = res[0];
				}
				else{
					cur_res = res[0];
					prev_res = pr_res.back();
				}
			}
			else{
				cur_res = res[i];
				prev_res = res[i-1];
				
			}
			cur_abs_err = fabs(cur_res - prev_res);
			cur_rel_err = fabs((cur_res - prev_res) / cur_res);
			if (cur_abs_err < abs_err || cur_rel_err < rel_err){
				break;
			}
		}
		pr_res.push_back(res.back());
		if (steps > max_steps){
			break;
		}
	}
	return cur_res;
	
}




int main(int argc, char* argv[]){
    string filename("conf.txt");
    if(argc == 2)
        filename = argv[1];
    if(argc > 2) {
        cerr << "Too many arguments. Usage: \n"
                "<program>\n"
                "or\n"
                "<program> <config-filename>\n" << endl;
        return 1;
    }
    ifstream config_stream(filename);
    if(!config_stream.is_open()) {
        cerr << "Failed to open configuration file " << filename << endl;
        return 2;
    }

    configuration_t config;
    try{
        config = read_conf(config_stream);
    }catch (std::exception& ex)
    {
        cerr << "Error: " << ex.what() << endl;
        return 3;
    }

	auto stage1_start_time = get_current_time_fenced();
	double cur_abs_err, cur_rel_err;
    double cur_res = thread_shuberts_integral(config.minx, config.miny, config.maxx, config.maxy, config.m, config.steps, config.max_steps, config.abs_err, config.rel_err, cur_abs_err, cur_rel_err, config.numb_of_thr);

	auto finish_time = get_current_time_fenced();
    auto total_time = finish_time - stage1_start_time;
    cout << "Total time: " << to_us(total_time) << endl;
    cout<<setprecision(5)<<fixed;
    cout<<cur_res<<endl;
    cout<<cur_abs_err<<endl;
    cout<<cur_rel_err<<endl;
}