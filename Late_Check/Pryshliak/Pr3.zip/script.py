import os
import subprocess
 
def run_c_program(prog_dir, n, err):
    if n < 0 or err < 0:
        print('numbers should be positive!')
        return
    res = []
    min_time =0
    while 1:
        base = os.path.dirname(os.path.dirname(__file__))
        path = os.path.join(base, prog_dir)
        base = base.split(':')[0]
        file_path_compile = os.path.join(path, 'c.bat')
        file_path_run = os.path.join(path, 'c_run.bat')
        batch_file_compile = open(file_path_compile, 'w')
        batch_file_run = open(file_path_run, 'w')
        file_data = 'cd ' + path + '\n' + base + ':\n' + 'g++ -o wb paralel_integral.cpp 2>compile.txt'
        batch_file_compile.write(file_data)
        batch_file_compile.close()
        file_data = file_data = 'cd ' + path + '\n' + base + ':\n' + 'wb.exe ' +' >Yay.txt'
        batch_file_run.write(file_data)
        batch_file_run.close()
        p = subprocess.Popen(file_path_compile)
        p.wait()
        file_path = os.path.join(path, 'compile.txt')
        compile_txt = open(file_path)
        if compile_txt.read() == '':
            p = subprocess.Popen(file_path_run)
        with open('Yay.txt') as f:
            lines = f.readlines()
            lines = [x.strip() for x in lines]
            if lines == []:
                continue
            else:
                if min_time == 0:
                    min_time = lines[0][12:]
                elif min_time < lines[0][12:]:
                    continue
                else:
                    min_time = lines[0][12:]
                res.append(float(lines[1]))
        if len(res) == n:
            break
    if (min(res) - max(res)) > err:
        print('result is wrong')
    else:
        print('result is correct')
    print(min_time)
    return 0
run_c_program('Desktop', 1, 0.1)

