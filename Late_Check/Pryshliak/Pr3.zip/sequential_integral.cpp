#include <iostream>
#include <fstream>
#include <limits>
#include <chrono>
#include <cassert>
#include <atomic>
#include <cmath>
#include <exception>
#include <stdexcept>
#include <string>
#include <list>
#include <iomanip>
#include <thread>
#include <vector>
#include <mutex>

using namespace std;


inline std::chrono::steady_clock::time_point get_current_time_fenced() {
    assert(std::chrono::steady_clock::is_steady &&
                   "Timer should be steady (monotonic).");
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::steady_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}


template<class D>
inline long long to_us(const D& d)
{
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}


struct configuration_t
{
    double rel_err, abs_err;
    double minx, miny, maxx, maxy;
    int m;
    int steps, max_steps;
    int numb_of_thr;
};


configuration_t read_conf(istream& cf)
{
    ios::fmtflags flags( cf.flags() );
    cf.exceptions(std::ifstream::failbit);

    configuration_t res;
    string temp;

    try {
        cf >> res.rel_err;
        getline(cf, temp);
        cf >> res.abs_err;
        getline(cf, temp);
        cf >> res.minx;
        getline(cf, temp);
        cf >> res.miny;
        getline(cf, temp);
        cf >> res.maxx;
        getline(cf, temp);
        cf >> res.maxy;
        getline(cf, temp);
        cf >> res.m;
        getline(cf, temp);
        cf >> res.steps;
        getline(cf, temp);
        cf >> res.max_steps;
        getline(cf, temp);
        cf >> res.numb_of_thr;
        getline(cf, temp);
    }catch(std::ios_base::failure &fail)
    {
        cf.flags( flags );
        throw;
    }
    cf.flags( flags );
    if( res.minx >= res.maxx ) {
        throw std::runtime_error("min x should be < max x");
    }
    if( res.miny >= res.maxy ) {
        throw std::runtime_error("min y should be < max y");
    }
    if( res.steps < 10 ) {
        throw std::runtime_error("Too few initial_steps");
    }
    if( res.max_steps < 10 ) {
        throw std::runtime_error("Too small max_steps");
    }
    if( res.abs_err <=0 || res.rel_err <= 0 )
    {
        throw std::runtime_error("Errors should be positive");
    }
    if( res.numb_of_thr <=0 )
    {
        throw std::runtime_error("Number of threads should be positive");
    }

    return res;
}


double shuberts_func(double x, double y, int m){
    double res = 0;
    double res1 = 0;
    double res2 = 0;
    for(int i=1; i<m+1; i++){
        res1 += i * cos((i+1)*x + 1);
        res2 += i * cos((i+1)*y + 1);
    }
    res = -res1 * res2;
    return res;
}


double shuberts_integral(double minx, double miny,double maxx, double maxy, int m, int steps){
    double res = 0;
    double delta_x = (maxx - minx)/steps;
    double delta_y = (maxy - miny)/steps;
    for(int i=0; i<steps; i++){
        double x = minx + i*delta_x;
        for(int j=0; j<steps; j++){
            double y = miny + j*delta_y;
            res +=shuberts_func(x, y, m)*delta_x*delta_y;
        }
    }
    return res;

}




int main_pr(){
    string filename("conf.txt");
    if(argc == 2)
        filename = argv[1];
    if(argc > 2) {
        cerr << "Too many arguments. Usage: \n"
                "<program>\n"
                "or\n"
                "<program> <config-filename>\n" << endl;
        return 1;
    }
    ifstream config_stream(filename);
    if(!config_stream.is_open()) {
        cerr << "Failed to open configuration file " << filename << endl;
        return 2;
    }

    configuration_t config;
    try{
        config = read_conf(config_stream);
    }catch (std::exception& ex)
    {
        cerr << "Error: " << ex.what() << endl;
        return 3;
    }

    
    double cur_res = shuberts_integral(config.minx, config.miny, config.maxx, config.maxy, config.m, config.steps);
    double prev_res = cur_res;
    double cur_abs_err, cur_rel_err;

	auto stage1_start_time = get_current_time_fenced();
	
    while(config.steps < config.max_steps){
        prev_res = cur_res;
        config.steps *= 2;
        cur_res = shuberts_integral(config.minx, config.miny, config.maxx, config.maxy, config.m, config.steps);
        cur_abs_err = fabs(cur_res-prev_res);
        cur_rel_err = fabs( (cur_res-prev_res)/cur_res );
        if ( cur_abs_err < config.abs_err && cur_rel_err < config.rel_err ){
                break;
        }

    }
    auto finish_time = get_current_time_fenced();
    auto total_time = finish_time - stage1_start_time;
    cout << "Total time: " << to_us(total_time) << endl;
    std::cout<<setprecision(5)<<fixed;
    std::cout<<cur_res<<endl;
    std::cout<<cur_abs_err<<endl;
    std::cout<<cur_rel_err<<endl;

}