#include <cmath>
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <atomic>
#include <mutex>
#include <vector>
#include <string>

struct config {
    int n{};
    int numOfThreads{};

    double expected_value{};
    double expected_abs_err{};
    double expected_rel_err{};

    double x_interval[2]{};
    double y_interval[2]{};

    config() = default;

    explicit config(std::vector<std::string> config_vector) {
        n = std::stoi(config_vector[0].substr(config_vector[0].find('=') + 1));
        numOfThreads = std::stoi(config_vector[1].substr(config_vector[1].find('=') + 1));
        expected_value = std::stod(config_vector[2].substr(config_vector[2].find('=') + 1));
        expected_abs_err = std::stod(config_vector[3].substr(config_vector[3].find('=') + 1));
        expected_rel_err = std::stod(config_vector[4].substr(config_vector[4].find('=') + 1));
        x_interval[0] = std::stod(config_vector[5].substr(config_vector[5].find('=') + 1));
        x_interval[1] = std::stod(config_vector[6].substr(config_vector[6].find('=') + 1));
        y_interval[0] = std::stod(config_vector[7].substr(config_vector[7].find('=') + 1));
        y_interval[1] = std::stod(config_vector[8].substr(config_vector[8].find('=') + 1));
    };
};

inline std::chrono::high_resolution_clock::time_point get_current_time_fenced() {
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D &d) {
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}

std::vector<std::string> readFile(const std::string &file) {

    std::vector<std::string> lines;
    std::string tmp_string;

    std::ifstream filesystem;

    filesystem.open(file, std::ifstream::in);

    if (!filesystem.is_open()) {
        std::cerr << "Could not open config file.";
        exit(2);
    }

    while (filesystem >> tmp_string) {
        lines.emplace_back(std::move(tmp_string));
    }
    filesystem.close();

    if (lines.size() > 9) {
        std::cerr << "Too many arguments." << std::endl;
        exit(22);
    }

    return lines;

}

double AckleyFunction(double x1, double x2) {
    double a = 20;
    double b = 0.2;
    double c = 2 * M_PI;

    double first_exp = exp(-b * sqrt(1.0 / 2 * (x1 * x1 + x2 * x2)));
    double second_exp = exp(1.0 / 2 * (cos(c * x1) + cos(c * x2)));

    return -a * first_exp - second_exp + a + exp(1);
}

void sumDoubleIntegral(int n, int start, int finish,
                       const double *x_interval,
                       const double *y_interval,
                       double &res, std::mutex &integral_mutex) {

    double lower_x = x_interval[0], upper_x = x_interval[1];
    double lower_y = y_interval[0], upper_y = y_interval[1];

    double delta_x = (upper_x - lower_x) / n;
    double delta_y = (upper_y - lower_y) / n;

    double x_value = 0;
    double y_value = 0;

    double sum = 0;
    double temp_sum = 0;

    for (int i = 0; i < n; ++i) {
        y_value = lower_y + delta_y * i;
        temp_sum = 0;
        for (int j = start; j < finish; ++j) {
            x_value = lower_x + delta_x * j;
            temp_sum += AckleyFunction(x_value, y_value);
        }
        sum += temp_sum * delta_y * delta_x;
    }

    integral_mutex.lock();
    res += sum;
    integral_mutex.unlock();

}


int main(int argc, char *argv[]) {

    config config_structure;
    std::string config_name;

    try {
        config_name = "./config.txt";
        config_structure = config(readFile(config_name));
    } catch (std::exception &excep) {
        std::cerr << "Invalid options." << std::endl;
        exit(22);
    }

    double result = 0;
    double previous_result = 0;

    double absolute_error = 0;
    double relative_error = 0;

    int x, y;
    int start, finish;

    std::vector<std::thread> threads;
    std::mutex integral_mutex;

    auto start_time = get_current_time_fenced();

    for (;;) {

        x = config_structure.n / config_structure.numOfThreads;
        y = 0;
        result = 0;

        finish = 0;
        start = 0;

        for (int i = 1; i < config_structure.numOfThreads; i++) {
            y += x;
            start = y - x;
            finish = y;
            threads.emplace_back(sumDoubleIntegral,
                                 config_structure.n, start, finish,
                                 config_structure.x_interval, config_structure.y_interval,
                                 std::ref(result), std::ref(integral_mutex));
        }

        threads.emplace_back(sumDoubleIntegral,
                             config_structure.n, finish, config_structure.n,
                             config_structure.x_interval, config_structure.y_interval,
                             std::ref(result), std::ref(integral_mutex));

        for (auto &thread : threads)
            thread.join();

        threads.clear();

        if (previous_result == 0) {
            previous_result = result;
            continue;
        }

        absolute_error = std::fabs(result - previous_result);
        relative_error = std::fabs(config_structure.expected_abs_err) / config_structure.expected_value;

        if (absolute_error < config_structure.expected_abs_err) {
            break;
        } else {
            config_structure.n *= 2;
        }
    }

    float finish_time = to_us(get_current_time_fenced() - start_time);

    std::cout << "Result: " << result << std::endl;
    std::cout << "Absolute error: " << absolute_error << std::endl;
    std::cout << "Relative error: " << relative_error << std::endl;
    std::cout << "Total time: " << finish_time / 1000000 << std::endl;
}
