from subprocess import Popen, PIPE
from sys import exit

class FilesNotEqual(Exception):
	pass
try:
    i = int(input("Iterations(must be integer number): "))
    print("Number of iterations: ", i)
except ValueError:
    print("ValueError: Please enter integer next time")
    exit()

program = "./integral"

result_lst = []
time_lst = []


for i in range(i):
    result = Popen(program, stdout=PIPE)
    out = result.stdout.read()
    x = str(out, "utf-8")
    time_lst.append(x.split()[-1]);
    result_lst.append(x.split()[1]);

for x in result_lst:
	for y in result_lst:
		if x != y:
			print("Not equal")
			exit

print("Results:", result_lst)
print("Times: ", time_lst)
print("Minimum time: ", min(time_lst))
