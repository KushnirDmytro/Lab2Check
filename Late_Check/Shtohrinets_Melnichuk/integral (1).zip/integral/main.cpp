#include <cmath>
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <atomic>
#include <mutex>
#include <vector>
#include <string>

inline std::chrono::high_resolution_clock::time_point get_current_time_fenced() {
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D &d) {
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}

double function3(const double &x, const double &y) {

    double res1 = 0, res2 = 0;

    for (int i = 1; i <= 5; ++i) {
        res1 += i * cos((i + 1) * x + 1);
        res2 += i * cos((i + 1) * y + 1);
    }
    return -res1 * res2;
}

double function4(const double &x, const double &y) {

    double res = 0;
    double c[5] = {2, 1, 4, 7, 2};
    double a1[5] = {1, 2, 1, 1, 5};
    double a2[5] = {4, 5, 1, 2, 4};

    for (int i = 0; i < 5; ++i) {
        res += c[i] * exp(-(1 / M_PI) * (pow((x - a1[i]), 2) + pow((y - a2[i]), 2))) *
               cos(M_PI * (pow((x - a1[i]), 2) + pow((y - a2[i]), 2)));
    }
    return -res;
}

void integrate(int n, int st, int fn, const double bounds[], double &res, std::mutex &mu) {

    double lboundX = bounds[0], uboundX = bounds[1], lboundY = bounds[2], uboundY = bounds[3];

    double dy = (uboundY - lboundY) / n;
    double dx = (uboundX - lboundX) / n;

    double sum = 0;

    for (int i = 0; i < n; ++i) {
        double y_val = lboundY + dy * i;
        double innerSum = 0;
        for (int j = st; j < fn; ++j) {
            double x_val = lboundX + dx * j;
            double funcRes = function4(x_val, y_val);

            innerSum += funcRes;
        }
        sum += innerSum * dy * dx;
    }

    mu.lock();
    res += sum;
    mu.unlock();

}

void handleArgs(double &abs_err, double &rel_err, int &numOfThreads, int &n, double *bounds, double &expected) {

    std::ifstream config("./config.txt");

    if (!config.is_open()) {
        std::cerr << "Could not open config file.";
        exit(2);
    }

    std::string s;
    std::vector<std::string> data;

    while (std::getline(config, s)) {
        data.emplace_back(s);
    }

    if (data.size() != 9) {
        std::cerr << "Invalid config file.";
        exit(2);
    }

    try {
        numOfThreads = std::stoi(data[0].substr(data[0].find('=') + 1));
        for (int x = 0; x < 4; x++) {
            bounds[x] = std::stod(data[1 + x].substr(data[1 + x].find('=') + 1));
        }
        expected = std::stod(data[5].substr(data[5].find('=') + 1));
        abs_err = std::stod(data[6].substr(data[6].find('=') + 1));
        rel_err = std::stod(data[7].substr(data[7].find('=') + 1));
        n = std::stoi(data[8].substr(data[8].find('=') + 1));
    } catch (std::exception &e) {
        std::cerr << e.what() << " error\n";
    }
}


int main(int argc, char *argv[]) {

    double expected = 0;
    double abs_err = 0;
    double rel_err = 0;
    int numOfThreads = 0;
    int n = 500;
    double bounds[] = {-10, 10, -10, 10};

    handleArgs(abs_err, rel_err, numOfThreads, n, bounds, expected);

    std::vector<std::thread> threads;
    std::mutex mu;

    auto start = get_current_time_fenced();
    bool run = true;
    double res = 0;
    double prev_res = 0;

    while (run) {

        int x = n / numOfThreads, y = 0;
        res = 0;

        int fn = 0;
        int st = 0;

        for (int i = 1; i < numOfThreads; i++) {
            y += x;
            st = y - x;
            fn = y;
            threads.emplace_back(integrate, n, st, fn, bounds, std::ref(res), std::ref(mu));
        }

        threads.emplace_back(integrate, n, fn, n, bounds, std::ref(res), std::ref(mu));

        for (auto &thread : threads) thread.join();
        threads.clear();

        if (prev_res == 0) {
            prev_res = res;
            continue;
        }

        double abs_err_cur = std::abs(res - prev_res);
        double rel_err_cur = std::abs(abs_err) / expected;
        //std::cout << "Abs: " << abs_err_cur << "\nRel: " << rel_err_cur << "\n";
        //std::cout << res << "\n";

        if (abs_err_cur >= abs_err) {
            n *= 2;
            continue;
        } else  {
            run = false;
            std::cout << "Abs: " << abs_err_cur << "\nRel: " << rel_err_cur << "\n";
        }

    }

    float finish = to_us(get_current_time_fenced() - start);

    std::cout << "Total time: " << finish / 1000000 << std::endl;
    std::cout << "Result: " << res << std::endl;

}
