from subprocess import Popen, PIPE
from sys import exit

try:
    i = int(input("Iterations(must be integer number): "))
except ValueError:
    print("ValueError: Please enter integer next time")
    exit()

program = "./intgral"
#program = "pwd"

lst = list()
time = list()

for i in range(i):
    result = Popen(program, stdout=PIPE)
    out = result.stdout.read()
    t = (str(out, "utf-8")).split('\n')[-3]
    time.append(float(t.split(' ')[-1]))
    x = (str(out, "utf-8")).split('\n')[-2]
    lst.append(float(x.split(' ')[-1]))

for i in lst:
    for j in lst:
        if i != j:
            print("not equal")
            exit()

print("Results:", lst)
print("Minimum result: ", min(time), "s")
