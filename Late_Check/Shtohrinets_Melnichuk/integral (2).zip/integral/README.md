#Integral_AKS_lab
##Made by Vlad Melnychuk & Bohdan Shtohrinets
##Instruction:
1.run python script(runner.py): python3 runner.py
2.Choose number of iterations:(for example 3)
3.You`ll get results=)

Example of work with different num of threads in graph.png
