// This is a personal academic project. Dear PVS-Studio, please check it.
// PVS-Studio Static Code Analyzer for C, C++ and C#: http://www.viva64.com

#include <cmath>
#include <iostream>
#include <iomanip>
#include <thread>
#include <atomic>
#include <mutex>
#include <vector>
#include <fstream>
#include <map>
#include <string>

inline std::chrono::high_resolution_clock::time_point get_current_time_fenced() {
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D &d) {
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}

std::atomic<int> count{0};

double func(double x1, double x2, int m) {

    double res1 = 0, res2 = 0;

    for (int i = 1; i <= m; ++ i) {
        res1 += i * cos((i + 1) * x1 + 1);
        res2 += i * cos((i + 1) * x2 + 1);
    }
    count += 1;
    return - res1 * res2;
}


void
integrate_thread(double x1_start, double x1_end, double x2_start, double x2_end, double dx, int m, std::mutex &mx,
                 double &res) {
    double sum = 0;
    for (double x1 = x1_start; x1 < x1_end; x1 += dx) {
        for (double x2 = x2_start; x2 < x2_end; x2 += dx) {
//            innersum += func(x1 + dx / 2.0, x2 + dx / 2.0, m);
            sum += func(x1, x2, m);
        }
    }
    sum *= dx * dx;
    mx.lock();
//    std::lock_guard<std::mutex> lg(mx);
    res += sum;
    mx.unlock();

}

void read_config(const std::string &filename, double &x1_start, double &x1_end, double &x2_start, double &x2_end,
                 int &n, int &m, int &numOfThreads, double &abs_acc, double &rel_acc) {
    std::map<std::string, std::string> Map;
    std::ifstream file(filename);
    std::string str;
    std::string a, b, c;
    while (file >> a >> b >> c) {
        if (a.empty() || a[0] == '#')
            continue;
        if (b != "=")
            std::cerr << "Wrong line in configuration file; read the example.txt" << std::endl;
        Map[a] = c;
        std::cout << a << " - element, value - " << c << std::endl;
    }

//
//    while (std::getline(file, str)) {
//        if (str[0] == '#') {
//            continue;
//
//        }
//        auto first = str.find_first_of(' ') - 1;
//        auto second = str.find_last_of(' ');
//        if (not(first && second)) {
//            std::cerr << "Wrong line in configuration file; read the example.txt";
//        }
//        std::string element = str.substr(0, first - 1);
//        std::string value = str.substr(second);
//        Map[element] = value;
//        std::cout << element << " - element, value - " << value << "\n";
//    }

    m = std::stoi(Map["m"]);
    std::cout << "@" << std::flush;
    n = std::stoi(Map["n"]);
    std::cout << "@" << std::flush;
    x1_start = std::stod(Map["x1_start"]);
    std::cout << "@" << std::flush;
    x1_end = std::stod(Map["x1_end"]);
    std::cout << "@" << std::flush;
    x2_start = std::stod(Map["x2_start"]);
    std::cout << "@" << std::flush;
    x2_end = std::stod(Map["x2_end"]);
    std::cout << "@" << std::flush;
    numOfThreads = std::stoi(Map["numOfThreads"]);
    std::cout << "@" << std::flush;

    abs_acc = std::stod(Map["abs_acc"]);
    std::cout << "@" << std::flush;
    rel_acc = std::stod(Map["rel_acc"]);
    std::cout << "@" << std::endl;
}

int main() {
    std::string filename = "example.txt";
    std::vector<std::thread> threads;
    std::mutex mx;
    int m;

    double x1_start, x1_end, x2_start, x2_end, abs_acc, rel_acc = 0;

    int numOfThreads;
    int n;

    read_config(filename, x1_start, x1_end, x2_start, x2_end, n, m, numOfThreads, abs_acc, rel_acc);
    double abs_err = abs_acc * 1.05;
    double rel_err = abs_acc * 1.05;
    double res1 = 0, res2 = 0;
    double x1_per_thread = fabs(x1_end - x1_start) / (double) numOfThreads;
    double dx = fabs(x1_start - x1_end) / (double) n;
    std::cerr<< std::setprecision(10) << dx << " - dx " << std::endl;
    auto start = get_current_time_fenced();
    for (int i = 1; i <= numOfThreads; i ++) {
        double startx1 = x1_start + (i - 1) * x1_per_thread;
        double stopx1 = x1_start + i * x1_per_thread;
        std::cout << std::setprecision(10) << startx1 << " - " << stopx1 << std::endl;
        threads.emplace_back(integrate_thread, startx1, stopx1,
                             x2_start,
                             x2_end, dx, m, std::ref(mx), std::ref(res1));

    }
    for (auto &thread : threads) thread.join();
    threads.clear();
    while (abs_err >= abs_acc or rel_err >= rel_acc){
        for (int i = 1; i <= numOfThreads; i ++) {
            double startx1 = x1_start + (i - 1) * x1_per_thread;
            double stopx1 = x1_start + i * x1_per_thread;
            threads.emplace_back(integrate_thread, startx1, stopx1,
                                 x2_start,
                                 x2_end, dx/2, m, std::ref(mx), std::ref(res2));

        }
        for (auto &thread : threads) thread.join();
        threads.clear();
         abs_err = fabs(res1- res2);
         rel_err = abs_err/fmax(res1,res2);
         dx /= 2;
         res1 = res2;
    }



//    for (int i = 1; i <= numOfThreads; i ++) {
//        double startx1 = x1_start + (i - 1) * x1_per_thread;
//        double stopx1 = x1_start + i * x1_per_thread;
//        std::cout << std::setprecision(10) << startx1 << " - " << stopx1 << std::endl;
//        threads.emplace_back(integrate_thread, startx1, stopx1,
//                             x2_start,
//                             x2_end, dx, m, std::ref(mx), std::ref(res1));
//
//    }
//    for (auto &thread : threads) thread.join();
//    threads.clear();

    float finish = to_us(get_current_time_fenced() - start);
    std::cout<< std::setprecision(10) << dx << " - dx " << std::endl;
    std::cout << res1 << " result\n";
    std::cout << finish / 1000000 << " seconds - time" << std::endl;
    std::cout << abs_err << " - abs error;" << std::endl;
    std::cout << rel_err << " - rel error;" << std::endl;
    std::cout << count << " - count of executions" << std::endl;
}