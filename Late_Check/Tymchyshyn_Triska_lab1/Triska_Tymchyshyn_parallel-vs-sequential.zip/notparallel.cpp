#include <iostream>
#include <chrono>
#include <atomic>
#include <stdio.h>
#include <math.h>

using namespace std;

inline chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    atomic_thread_fence(memory_order_seq_cst);
    auto res_time = chrono::high_resolution_clock::now();
    atomic_thread_fence(memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D &d)
{
    return chrono::duration_cast<chrono::microseconds>(d).count();
}


int main(int argc, char *argv[])
{
    auto start_time = get_current_time_fenced();
    const int n = 50;
    int count = 0;
    for (int x = 1; x <= n; x++) {
        for (int y = 1; y <= n; y++) {
            for (int z = 1; z <= n; z++) {
                for (int w = 1; w <= n; w++) {
                    if ((pow(w, 3) + pow(z, 3) == pow(x, 3) + pow(y, 3)) && (z != x) && (z != y)) {
                        count++;
                    }
                }
            }
        }

    }

    auto finish_time = get_current_time_fenced();
    auto total_time = finish_time - start_time;

    cout << count << endl;
    cout << "Total time: " << to_us(total_time) << endl;
    return 0;
}