#include <iostream>
#include <chrono>
#include <atomic>
#include <mutex>
#include <thread>
#include <stdio.h>
#include <math.h>

using namespace std;

inline chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    atomic_thread_fence(memory_order_seq_cst);
    auto res_time = chrono::high_resolution_clock::now();
    atomic_thread_fence(memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D &d)
{
    return chrono::duration_cast<chrono::microseconds>(d).count();
}


void worker(int n2, int beg, int fin, int &count, mutex &m)
{
    int i = 0;
    for (int x = beg; x <= fin; x++) {
        for (int y = 1; y <= n2; y++) {
            for (int z = 1; z <= n2; z++) {
                for (int w = 1; w <= n2; w++) {
                    if ((pow(w, 3) + pow(z, 3) == pow(x, 3) + pow(y, 3)) && z != x && z != y) {
                        i++;
                    }
                }
            }
        }
    }
    m.lock();
    count += i;
    m.unlock();
}

int main(int argc, char *argv[])
{

    auto start_time = get_current_time_fenced();

    const int n = 50;
    int number_of_threads = 6;
    int count = 0;

    if (argv[1]) {
        number_of_threads = stoi(argv[1]);
    }

    mutex mux;
    thread threads[number_of_threads];
    int num = n / number_of_threads;

    for (int i = 0; i < number_of_threads; ++i) {
        threads[i] = thread(worker, n, i * num + 1, (i + 1) * num, ref(count), ref(mux));
    }
    for (int i = 0; i < number_of_threads; ++i) {
        threads[i].join();
    }
    auto finish_time = get_current_time_fenced();
    auto total_time = finish_time - start_time;

    cout << count << endl;
    cout << "Total time: " << to_us(total_time) << endl;

    return 0;
}
