//
// Created by arsen on 29.05.18.
//
#include <iostream>
#include <chrono>
#include <atomic>
#include<map>
#include<string>
#include<vector>
#include<cmath>
#include <math.h>
#include <mutex>
#include <thread>

using std::vector;
using std::cout;
using std::cin;
using std::map;
using std::endl;
using std::string;
using std::ref;
int STEPS = 1000;

inline std::chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D& d)
{
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}

double myfunc(double x, double y, int n, vector<int> c, vector<int> a1, vector<int> a2){
    double res;
    for(int i = 0; i < n; ++i) {
        res += -c[i] * exp(-(pow(x - a1[i], 2) + pow(y - a2[i], 2)) / M_PI) * cos((pow(x - a1[i], 2) + pow(y - a2[i], 2)) * M_PI);
    }
    return res;
}

void calc(double x1,double x2,double y1, double y2,int step, int n,vector<int> c, vector<int> a1, vector<int> a2, double &count, std::mutex& m) {
    double res = 0.0;
    double dx = (x2-x1)/step;
    double dy = (y2-y1)/step;
    double cache = y1;
    while (x1<x2){
        while(y1<y2) {
            res += myfunc(x1, y1,n,c,a1,a2)*dx*dy;
            y1+=dy;
        }
        x1+=dx;
        y1=cache;
    }
    m.unlock();
    count +=res;
    m.lock();
}


int main(int argc, const char* argv[]){
    auto start_time = get_current_time_fenced();
    double prev = 0;
    int iter=0;
    double count = 0.0;
    double myabs = 100;
    double myrel = 100;
    int number_of_threads;
    int x1;
    int x2;
    int y1;
    int y2;
    double abs;
    double rel;
    int max_iter;
    vector<int> mas_a1 = {1, 2, 1, 1, 5};
    vector<int> mas_a2 = {4, 5, 1, 2, 4};
    vector<int> mas_c = {2, 1, 4, 7, 2};
    int n =5;
    if(argc == 9){
        number_of_threads = std::stoi(argv[1]);
        x1 = std::stoi(argv[2]);
        x2 = std::stoi(argv[3]);
        y1 = std::stoi(argv[4]);
        y2 = std::stoi(argv[5]);
        abs = std::stod(argv[6]);
        rel = std::stod(argv[7]);
        max_iter = std::stoi(argv[8]);
    }
    std::mutex mux;
    std::thread threads[number_of_threads];
    while(myabs > abs && myrel > rel && iter < max_iter){
        count = 0.0;
        for (int i = 0; i < number_of_threads; ++i) {
            threads[i] = std::thread(calc, x1 + i*(x2 - x1)/number_of_threads,
                                 x1 + (i + 1)*(x2 - x1)/number_of_threads,
                                 y1, y2, STEPS/number_of_threads,n,mas_c,mas_a1,mas_a2, ref(count), ref(mux));
        }
        for (int i = 0; i < number_of_threads; ++i) {
            threads[i].join();
        }
        STEPS*=2;
        myabs = fabs(count - prev);
        myrel = fabs(1 - count/prev);
        prev = count;
        cout<<count<<endl;
        iter++;
    }
    auto finish_time = get_current_time_fenced();
    auto total_time = finish_time - start_time;
    cout<< "Absolute err: " << myabs << endl << "Rel: " << myrel << endl;
    cout<<"Result: "<<count<<endl;
    cout << "Total time: " << to_us(total_time) << endl;
    return 0;
}